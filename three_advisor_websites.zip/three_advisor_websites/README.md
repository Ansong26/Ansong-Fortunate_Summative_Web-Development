# Three Student Advisor Web Applications

This package contains three independent GitHub Pages-ready applications for the three assessment scenarios:
- BSE Specialisation Advisor
- Soft Skills Advisor
- GCGO Advisor

Each folder contains index.html, styles.css, script.js and README.md.

Before submission:
- Replace the author name and repository/live links.
- Test every interaction on desktop and mobile.
- Record the 10–15 minute walkthrough.
- Export your final Sources & Attribution document as PDF.
